
<style>
    .dataTables_length{
        color:#0000C0 !important;
    }.breadcrumb a{
        color:#285e8e !important;font-size:12px !important;
    }.tengah{text-align: center !important;}#table4 thead th{text-align: center !important;vertical-align: middle;}
</style>
<h4 style="text-align: center;">TAHUN 2017</h4>
<h4 style="text-align: center;">MENGEMBANGKAN APLIKASI EKINERJA</h4>
<div>
    <table id="table4" border="0.5" style="border:1px;width:100%;">
      
            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">JANUARI</td>
            </tr>
            <tr style="background:rgb(226,108,10);text-align:center;font-weight:bold;"><td>No</td><td>Kegiatan Bulanan</td><td>Nilai Kualitas Bulanan</td></tr>
            <tr><td align="center">1</td><td>Menyusun proses bisnis ekinerja</td><td align="right">100</td></tr> <tr><td align="center">2</td><td>Mengumpulkan data ekinerja</td><td align="right">91</td></tr> <tr><td align="center">3</td><td>membuat database struktur</td><td align="right"></td></tr>                        <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">FEBRUARI</td>
            </tr>

            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">MARET</td>
            </tr>

            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">APRIL</td>
            </tr>

            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">MEI</td>
            </tr>

            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">JUNI</td>
            </tr>

            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">JULI</td>
            </tr>

            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">AGUSTUS</td>
            </tr>

            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">SEPTEMBER</td>
            </tr>

            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">OKTOBER</td>
            </tr>

            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">NOVEMBER</td>
            </tr>

            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">DESEMBER</td>
            </tr>

        </tbody></table></div>                    


<h4 style="text-align: center;">MENERIMA SURAT MASUK</h4>
<div>
    <table id="table4" border="0.5" style="border:1px;width:100%;">
        <tbody>
            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">JANUARI</td>
            </tr>
            <tr style="background:rgb(226,108,10);text-align:center;font-weight:bold;"><td>No</td><td>Kegiatan Bulanan</td><td>Nilai Kualitas Bulanan</td></tr>
            <tr><td align="center">1</td><td>Menerima surat Masuk</td><td align="right">99</td></tr>                        <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">FEBRUARI</td>
            </tr>

            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">MARET</td>
            </tr>

            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">APRIL</td>
            </tr>

            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">MEI</td>
            </tr>

            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">JUNI</td>
            </tr>

            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">JULI</td>
            </tr>

            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">AGUSTUS</td>
            </tr>

            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">SEPTEMBER</td>
            </tr>

            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">OKTOBER</td>
            </tr>

            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">NOVEMBER</td>
            </tr>

            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">DESEMBER</td>
            </tr>

        </tbody></table></div>                    
<h4 style="text-align: center;">MEMBUAT KONSEP PRSES BISNIS EKINERJA</h4>
<div>
    <table id="table4" border="0.5" style="border:1px;width:100%;">
        <tbody>
            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">JANUARI</td>
            </tr>
            <tr style="background:rgb(226,108,10);text-align:center;font-weight:bold;"><td>No</td><td>Kegiatan Bulanan</td><td>Nilai Kualitas Bulanan</td></tr>
            <tr><td align="center">1</td><td>Membuat draft flowchart proses bisnis</td><td align="right"></td></tr>                        <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">FEBRUARI</td>
            </tr>

            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">MARET</td>
            </tr>

            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">APRIL</td>
            </tr>

            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">MEI</td>
            </tr>

            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">JUNI</td>
            </tr>

            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">JULI</td>
            </tr>

            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">AGUSTUS</td>
            </tr>

            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">SEPTEMBER</td>
            </tr>

            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">OKTOBER</td>
            </tr>

            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">NOVEMBER</td>
            </tr>

            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">DESEMBER</td>
            </tr>

        </tbody></table></div>                    
<h4 style="text-align: center;">MENGEMBANGKAN APLIKASI EKINERJA</h4>
<div>
    <table id="table4" border="0.5" style="border:1px;width:100%;">
        <tbody>
            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">JANUARI</td>
            </tr>
            <tr style="background:rgb(226,108,10);text-align:center;font-weight:bold;"><td>No</td><td>Kegiatan Bulanan</td><td>Nilai Kualitas Bulanan</td></tr>
            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">FEBRUARI</td>
            </tr>

            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">MARET</td>
            </tr>

            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">APRIL</td>
            </tr>

            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">MEI</td>
            </tr>

            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">JUNI</td>
            </tr>

            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">JULI</td>
            </tr>

            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">AGUSTUS</td>
            </tr>

            <tr><td align="center">1</td><td>Testing aplikasi</td><td align="right">74</td></tr>                        <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">SEPTEMBER</td>
            </tr>

            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">OKTOBER</td>
            </tr>

            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">NOVEMBER</td>
            </tr>

            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">DESEMBER</td>
            </tr>

        </tbody></table></div>                    
<h4 style="text-align: center;">MENERIMA SURAT MASUK</h4>
<div>
    <table id="table4" border="0.5" style="border:1px;width:100%;">
        <tbody>
            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">JANUARI</td>
            </tr>
            <tr style="background:rgb(226,108,10);text-align:center;font-weight:bold;"><td>No</td><td>Kegiatan Bulanan</td><td>Nilai Kualitas Bulanan</td></tr>
            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">FEBRUARI</td>
            </tr>

            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">MARET</td>
            </tr>

            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">APRIL</td>
            </tr>

            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">MEI</td>
            </tr>

            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">JUNI</td>
            </tr>

            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">JULI</td>
            </tr>

            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">AGUSTUS</td>
            </tr>

            <tr><td align="center">1</td><td>Menerima surat Masuk</td><td align="right">72</td></tr>                        <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">SEPTEMBER</td>
            </tr>

            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">OKTOBER</td>
            </tr>

            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">NOVEMBER</td>
            </tr>

            <tr>
                <td colspan="3" style="background: rgb(15,36,63);color:white;text-align:center;">DESEMBER</td>
            </tr>

        </tbody></table></div>                    



